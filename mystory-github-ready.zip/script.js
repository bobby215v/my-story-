
const input = document.getElementById('post-input');
const preview = document.getElementById('preview');
const timeline = document.getElementById('timeline');
const avatar = document.getElementById('post-avatar');

function createPost(text, mediaSrc = null) {
  const card = document.createElement('div');
  card.className = 'entry-card';
  card.textContent = text;
  timeline.appendChild(card);
}

avatar.addEventListener('click', () => {
  const text = input.value.trim();
  if (text) {
    createPost(text);
    input.value = '';
  }
});

window.onload = () => {
  createPost('Welcome to MyStory!');
  createPost('This is a sample photo post.', 'https://example.com/image.jpg');
};
